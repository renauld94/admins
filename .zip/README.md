# Evidence Package README

This archive contains curated evidence for Contract 0925/CONSULT/DU.

## Key files and SHA-256 hashes


## Contents

See  for individual .eml exhibits and  for the manifest.

## Chain of custody

Files were exported from Google Takeout and processed locally on 2025-11-08T06:57:25Z UTC. SHA-256 hashes recorded above.

## Contents

The package contains a merged cover+exhibit PDF, the exhibits archive with selected .eml files, manifests, and supporting documents.

## Chain of custody

Files were exported from Google Takeout and processed locally on $(date -u +%Y-%m-%dT%H:%M:%SZ) UTC. SHA-256 hashes recorded above.
