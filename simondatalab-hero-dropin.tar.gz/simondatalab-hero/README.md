# Simondatalab Hero (Drop‑in)

A ready-to-embed interactive hero section featuring:

- Earth globe with animated arcs, points and rings
- Brain-like particle network with pulses
- City network overlays and human orbits
- Story overlay (Vimeo/YouTube) and a Reduce Motion toggle

## Files

- `hero.html` — Example page showing minimal markup, styles and initialization
- `assets/hero/hero-visualization.js` — Self-contained Three.js bundle exposing `window.initHeroVisualization(container)`

## Quick embed (copy/paste)

1. Copy the `assets/hero/hero-visualization.js` file into your site, e.g. `/assets/hero/hero-visualization.js`.
1. Add the HTML snippet where the hero should appear:

```html
<section class="hero-card">
  <header class="hero-head">
    <h1>Data + AI, Connected</h1>
    <nav class="viz-controls">
      <span class="chip active" data-mode="all">All</span>
      <span class="chip" data-mode="earth">Earth</span>
      <span class="chip" data-mode="brain">Brain</span>
      <span class="chip" data-mode="network">City Network</span>
      <span class="chip" id="chip-reel">Story</span>
    </nav>
  </header>
  <div class="hero-container" id="hero-container">
    <div class="viz-stats" aria-live="polite">globe/neuron/relations • reduce motion supported</div>
  </div>
</section>
```

1. Include the minimal styles (you can move these to your main stylesheet and adjust to your design system):

```html
<style>
  :root{ --c-sky:#0ea5e9; --c-violet:#8b5cf6; --c-cyan:#06b6d4; --c-bg:#0b1020; --c-fg:#e5e7eb; --c-sub:#9ca3af }
  .hero-card{ width:min(1200px, 95vw); border:1px solid rgba(148,163,184,0.22); border-radius:18px; padding: clamp(12px, 2vw, 22px); background: linear-gradient(180deg, rgba(2,6,23,0.85) 0%, rgba(2,6,23,0.65) 100%); box-shadow: 0 10px 40px rgba(2,6,23,0.6) }
  .hero-head{ display:flex; align-items:center; gap:12px; flex-wrap:wrap; justify-content:space-between; padding: 6px 6px 12px 6px }
  .viz-controls{ display:flex; gap:8px; flex-wrap:wrap }
  .chip{ cursor:pointer; padding: 6px 10px; border-radius:999px; border:1px solid rgba(148,163,184,0.35); color:#cbd5e1; background: rgba(2,6,23,0.6); -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); transition: all .2s ease; font-size: 13px }
  .chip.active{ background: linear-gradient(90deg, rgba(14,165,233,0.15), rgba(139,92,246,0.15)); border-color: rgba(139,92,246,0.6); color:#fff }
  .hero-container{ position:relative; width:100%; height: clamp(380px, 60vh, 620px); border-radius: 16px; overflow:hidden; border: 1px solid rgba(148,163,184,0.18); background: radial-gradient(1200px 400px at 40% -5%, rgba(14,165,233,0.35), transparent), radial-gradient(900px 600px at 80% 10%, rgba(139,92,246,0.25), transparent), linear-gradient(180deg, rgba(2,6,23,0.95), rgba(2,6,23,0.75)) }
  .viz-stats{ position:absolute; left:12px; bottom:12px; font-size:12px; color: var(--c-sub); z-index:12 }
</style>
```

1. Set your video (optional):

```html
<script>
  window.HERO_PERSONAL_REEL_URL = 'https://player.vimeo.com/video/XXXXXXXX';
</script>
```

1. Load the bundle and initialize:

```html
<script src="/assets/hero/hero-visualization.js"></script>
<script>
  window.addEventListener('DOMContentLoaded', ()=>{
    const container=document.getElementById('hero-container');
    window.initHeroVisualization(container);
  });
</script>
```

Notes:

- The bundle will auto-load Three.js r152 and three-globe 2.24.x from a CDN if not already present.
- The hero respects prefers-reduced-motion and includes a runtime toggle.
- If you have CSP enabled, allow the JS/CDN, Vimeo (if using), and inline styles as needed or move inline styles to your CSS.
