# Exhibit Index

Automatically generated index for the curated exhibits package.

|Exhibit file|Date|From|Subject|SHA256|
|-:|:-|:-|:-|:-:|
|bounce_000396.eml|Wed, 29 Oct 2025 01:19:05 -0700 (PDT)|Mail Delivery Subsystem <mailer-daemon@g|Delivery Status Notification (Failure)|662c60ead484|
|bounce_000009.eml|Wed, 29 Oct 2025 14:58:12 +0000 (UTC)|LinkedIn Job Alerts <jobalerts-noreply@l|=?UTF-8?Q?=E2=80=9CHead_of_Artificial_Intelligence=E2=80=9D:_Dream?=
 =?UTF-8?Q|6cd4302697b5|
|bounce_000225.eml|Wed, 29 Oct 2025 12:46:35 +0000 (UTC)|LinkedIn Job Alerts <jobalerts-noreply@l|=?UTF-8?Q?=E2=80=9CSenior_Data_Analyst=E2=80=9D:_Collectius_?=
 =?UTF-8?Q?-_Reg|4a6f4fe02add|
|bounce_000395.eml|Wed, 29 Oct 2025 12:56:18 +0000 (UTC)|LinkedIn Job Alerts <jobalerts-noreply@l|=?UTF-8?Q?=E2=80=9C("data"_AND_"french")=E2=80=9D:_Trans-Canada_Capit?=
 =?UTF-|dad161c47e46|
|bounce_000166.eml|Tue, 21 Oct 2025 14:25:00 -0700 (PDT)|Mail Delivery Subsystem <mailer-daemon@g|Delivery Status Notification (Failure)|c5df08f25072|
|bounce_000167.eml|Mon, 20 Oct 2025 18:15:14 -0700 (PDT)|Mail Delivery Subsystem <mailer-daemon@g|Delivery Status Notification (Delay)|7d9774088d36|
|bounce_000524.eml|Wed, 08 Oct 2025 03:52:36 -0700 (PDT)|Mail Delivery Subsystem <mailer-daemon@g|Delivery Status Notification (Failure)|8b12dc51236a|
|bounce_001303.eml|Fri, 10 Oct 2025 01:23:25 -0700 (PDT)|Mail Delivery Subsystem <mailer-daemon@g|Delivery Status Notification (Failure)|1aedbaec13ba|
