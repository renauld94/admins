# Draft Demand Letter

To: ICON PLC / Digital Unicorn Services

Re: Contract 0925/CONSULT/DU — Evidence of non-payment, account deactivation, and scope abuse.

Summary of key exhibits (automatically generated):

- `EXHIBIT_LUCAS_OCT10_PROMISE.txt` — payment promise (if present)
- Bounce evidence: see `mbox_matches/candidates_bounce_top20.csv` and selected `mbox_matches/bounce_*.eml`
- Screenshots & AI images: `screenshot_classification.csv` and `dalle_samples/` in evidence folder

Please find attached exhibits and contact the undersigned to resolve this matter within 7 days.
