"""digital_unicorn_outsource package init for ai detector"""
__version__ = '0.1'
