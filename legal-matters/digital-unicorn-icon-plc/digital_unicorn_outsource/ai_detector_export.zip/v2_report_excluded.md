# AI Detection Report

## Summary
- Total files analyzed: 6
- Files flagged (score >= 0.4): 6

## Flagged Files

- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.3/M2_2.3_EXERCISE.python**: ai (score=1.0)
- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.2/M2_2.2_EXERCISE.python**: ai (score=1.0)
- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.2/M2_2.2_DISPLAY.python**: ai (score=0.922)
- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.1/M2_2.1_EXERCISE.python**: ai (score=1.0)
- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.1/M2_2.1_DISPLAY.python**: ai (score=1.0)
- **/home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.3/M2_2.3_DISPLAY.python**: ai (score=1.0)

## All Results

- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.3/M2_2.3_EXERCISE.python: ai (score=1.0)
- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.2/M2_2.2_EXERCISE.python: ai (score=1.0)
- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.2/M2_2.2_DISPLAY.python: ai (score=0.922)
- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.1/M2_2.1_EXERCISE.python: ai (score=1.0)
- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.1/M2_2.1_DISPLAY.python: ai (score=1.0)
- /home/simon/Desktop/Learning Management System Academy/digital_unicorn_outsource/V2/Sessions 2.1 2.2 2.3/M_2.3/M2_2.3_DISPLAY.python: ai (score=1.0)
