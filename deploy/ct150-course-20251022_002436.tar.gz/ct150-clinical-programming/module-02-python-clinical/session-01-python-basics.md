# Session 2.01: Python Basics for Clinical Programming

## Learning Objectives
By the end of this session, you will be able to:
- Set up Python environment for clinical programming
- Understand Python data types relevant to clinical data
- Perform basic data manipulation operations
- Implement data validation functions

## Python Environment Setup

### CT 150 Server Python Configuration
```bash
# Check Python version
python3 --version

# Install required packages
pip3 install pandas numpy scipy matplotlib seaborn
pip3 install jupyter notebook
pip3 install sas7bdat pyreadstat

# Verify installation
python3 -c "import pandas, numpy, scipy; print('All packages installed successfully')"
```

### Jupyter Notebook Setup
```python
# Start Jupyter Notebook
jupyter notebook --ip=0.0.0.0 --port=8888 --no-browser --allow-root

# Access via browser: http://ct150-server:8888
```

## Python Data Types for Clinical Data

### Basic Data Types
```python
# Patient ID (string)
patient_id = "P001"
print(f"Patient ID: {patient_id}")

# Age (integer)
age = 45
print(f"Age: {age}")

# Weight (float)
weight = 70.5
print(f"Weight: {weight} kg")

# Treatment group (string)
treatment = "Active"
print(f"Treatment: {treatment}")

# Visit completed (boolean)
visit_completed = True
print(f"Visit completed: {visit_completed}")
```

### Clinical Data Structures
```python
# List of lab values
lab_values = [12.5, 15.2, 18.7, 14.3, 16.1]
print(f"Lab values: {lab_values}")

# Dictionary for patient demographics
patient_demo = {
    "patient_id": "P001",
    "age": 45,
    "gender": "M",
    "race": "White",
    "weight": 70.5
}
print(f"Patient demographics: {patient_demo}")

# Tuple for visit dates
visit_dates = ("2024-01-15", "2024-02-15", "2024-03-15")
print(f"Visit dates: {visit_dates}")
```

## Data Manipulation with Pandas

### Loading Clinical Data
```python
import pandas as pd
import numpy as np

# Load clinical trial data
def load_clinical_data(file_path):
    """Load clinical trial data from CSV file"""
    try:
        data = pd.read_csv(file_path)
        print(f"Data loaded successfully: {data.shape[0]} rows, {data.shape[1]} columns")
        return data
    except FileNotFoundError:
        print(f"File not found: {file_path}")
        return None
    except Exception as e:
        print(f"Error loading data: {e}")
        return None

# Example usage
data = load_clinical_data("clinical_trial_data.csv")
```

### Data Exploration
```python
def explore_clinical_data(df):
    """Explore clinical trial data"""
    print("=== CLINICAL DATA EXPLORATION ===")
    print(f"Dataset shape: {df.shape}")
    print(f"\nColumn names:")
    for i, col in enumerate(df.columns, 1):
        print(f"{i:2d}. {col}")
    
    print(f"\nData types:")
    print(df.dtypes)
    
    print(f"\nMissing values:")
    missing = df.isnull().sum()
    print(missing[missing > 0])
    
    print(f"\nBasic statistics:")
    print(df.describe())
    
    return df

# Example usage
if data is not None:
    explore_clinical_data(data)
```

## Data Validation Functions

### Range Validation
```python
def validate_age(age):
    """Validate age is within acceptable range"""
    if pd.isna(age):
        return False, "Age is missing"
    if not isinstance(age, (int, float)):
        return False, "Age must be numeric"
    if age < 18 or age > 100:
        return False, f"Age {age} is outside acceptable range (18-100)"
    return True, "Valid age"

def validate_lab_value(value, normal_range):
    """Validate lab value is within normal range"""
    if pd.isna(value):
        return False, "Lab value is missing"
    if not isinstance(value, (int, float)):
        return False, "Lab value must be numeric"
    if value < normal_range[0] or value > normal_range[1]:
        return False, f"Lab value {value} is outside normal range {normal_range}"
    return True, "Lab value within normal range"

# Example usage
age_valid, age_msg = validate_age(45)
print(f"Age validation: {age_valid}, {age_msg}")

lab_valid, lab_msg = validate_lab_value(12.5, (10.0, 20.0))
print(f"Lab validation: {lab_valid}, {lab_msg}")
```

### Data Quality Checks
```python
def check_data_quality(df):
    """Comprehensive data quality check"""
    issues = []
    
    # Check for missing values
    missing_cols = df.columns[df.isnull().any()].tolist()
    if missing_cols:
        issues.append(f"Missing values in columns: {missing_cols}")
    
    # Check for duplicate records
    duplicates = df.duplicated().sum()
    if duplicates > 0:
        issues.append(f"Found {duplicates} duplicate records")
    
    # Check for outliers in numeric columns
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    for col in numeric_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        outliers = df[(df[col] < Q1 - 1.5*IQR) | (df[col] > Q3 + 1.5*IQR)]
        if len(outliers) > 0:
            issues.append(f"Outliers found in {col}: {len(outliers)} records")
    
    return issues

# Example usage
if data is not None:
    quality_issues = check_data_quality(data)
    if quality_issues:
        print("Data quality issues found:")
        for issue in quality_issues:
            print(f"- {issue}")
    else:
        print("No data quality issues found")
```

## Clinical Data Processing

### Data Transformation
```python
def process_clinical_data(df):
    """Process clinical trial data"""
    # Create a copy to avoid modifying original data
    processed_df = df.copy()
    
    # Convert date columns
    date_columns = ['visit_date', 'birth_date', 'enrollment_date']
    for col in date_columns:
        if col in processed_df.columns:
            processed_df[col] = pd.to_datetime(processed_df[col], errors='coerce')
    
    # Create derived variables
    if 'birth_date' in processed_df.columns and 'visit_date' in processed_df.columns:
        processed_df['age_at_visit'] = (processed_df['visit_date'] - processed_df['birth_date']).dt.days / 365.25
    
    # Standardize categorical variables
    if 'gender' in processed_df.columns:
        processed_df['gender'] = processed_df['gender'].str.upper()
    
    return processed_df

# Example usage
if data is not None:
    processed_data = process_clinical_data(data)
    print("Data processing completed")
```

## Hands-On Exercise

### Exercise 1: Clinical Data Analysis
```python
# Create sample clinical data
np.random.seed(42)
n_patients = 100

clinical_data = pd.DataFrame({
    'patient_id': [f'P{i:03d}' for i in range(1, n_patients + 1)],
    'age': np.random.normal(50, 15, n_patients).astype(int),
    'gender': np.random.choice(['M', 'F'], n_patients),
    'treatment': np.random.choice(['Active', 'Placebo'], n_patients),
    'baseline_value': np.random.normal(100, 20, n_patients),
    'endpoint_value': np.random.normal(95, 18, n_patients),
    'adverse_events': np.random.poisson(2, n_patients)
})

# Ensure age is within reasonable range
clinical_data['age'] = np.clip(clinical_data['age'], 18, 80)

print("Sample Clinical Data:")
print(clinical_data.head())
print(f"\nDataset shape: {clinical_data.shape}")

# Perform data quality checks
quality_issues = check_data_quality(clinical_data)
if quality_issues:
    print("\nData quality issues:")
    for issue in quality_issues:
        print(f"- {issue}")
else:
    print("\nNo data quality issues found")

# Basic analysis
print(f"\nTreatment groups:")
print(clinical_data['treatment'].value_counts())

print(f"\nGender distribution:")
print(clinical_data['gender'].value_counts())

print(f"\nAge statistics:")
print(clinical_data['age'].describe())
```

## Best Practices

1. **Data Validation**: Always validate data before analysis
2. **Error Handling**: Implement proper error handling
3. **Documentation**: Document all data transformations
4. **Version Control**: Use Git for code versioning
5. **Testing**: Test all functions with sample data

## Next Steps

- Practice with real clinical data
- Learn advanced pandas operations
- Implement statistical analysis functions
- Explore data visualization techniques

## Resources

- [Pandas Documentation](https://pandas.pydata.org/docs/)
- [NumPy Documentation](https://numpy.org/doc/)
- [Clinical Data Standards](https://www.cdisc.org/)
- [CT 150 Server Documentation](https://www.simondatalab.de/docs/ct150)

---

**Session Duration**: 3 hours  
**Prerequisites**: Basic Python knowledge  
**Next Session**: Statistical Analysis with Python
