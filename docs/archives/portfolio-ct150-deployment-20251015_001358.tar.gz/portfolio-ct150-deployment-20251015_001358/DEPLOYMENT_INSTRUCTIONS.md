# 📦 Portfolio Deployment Instructions for CT150

## 🎯 Target Server
- **URL**: https://moodle.simondatalab.de/
- **Server**: CT150 - moodle.simondatalab.de
- **Target Path**: `/var/www/html/simondatalab`

## 🚀 Deployment Steps

### Method 1: Direct Upload (Recommended)
1. Extract this package on the target server
2. Copy all files to `/var/www/html/simondatalab/`
3. Set proper permissions:
   ```bash
   sudo chown -R www-data:www-data /var/www/html/simondatalab
   sudo chmod -R 755 /var/www/html/simondatalab
   sudo chmod 644 /var/www/html/simondatalab/.htaccess
   ```

### Method 2: Using SSH (if configured)
```bash
# Upload package
scp portfolio-ct150-deployment-20251015_001358.tar.gz user@moodle.simondatalab.de:/tmp/

# SSH to server
ssh user@moodle.simondatalab.de

# Extract and deploy
cd /tmp
tar -xzf portfolio-ct150-deployment-20251015_001358.tar.gz
sudo cp -r portfolio-ct150-deployment-20251015_001358/* /var/www/html/simondatalab/
sudo chown -R www-data:www-data /var/www/html/simondatalab
sudo chmod -R 755 /var/www/html/simondatalab
```

## 📋 What's Included

✅ **Core Files**
- `index.html` - Main portfolio page
- `epic-neural-cosmos-demo.html` - Epic visualization demo

✅ **Stylesheets**
- `css/styles.css` - Main styles
- `css/globe-fab.css` - Globe component styles
- `css/print.css` - Print styles

✅ **JavaScript Libraries**
- `js/three-loader.js` - Custom THREE.js loader
- `js/epic-neural-cosmos-viz.js` - Epic visualization system
- `js/app.js` - Main application logic
- `js/ai-integration.js` - AI integration features
- `js/hero-performance.js` - Performance optimizations
- `js/gsap.min.js` - Animation library
- `js/ScrollTrigger.min.js` - Scroll animations
- `js/d3.v7.min.js` - Data visualization library

✅ **Assets**
- Images, fonts, and other static assets
- Geospatial visualization components
- Favicon and branding assets

✅ **Configuration**
- `.htaccess` - Apache performance and security configuration

## 🌌 Features

🎨 **Epic Neural to Cosmos Visualization**
- Multi-phase journey: Neurons → Brain → Networks → Cosmos
- Automatic transitions every 15 seconds
- Professional presentation mode
- 4000+ particles per phase

🚀 **Performance Optimizations**
- Gzip compression enabled
- Asset caching configured
- THREE.js optimized loading
- Mobile responsive design

🔒 **Security Features**
- Security headers configured
- XSS protection enabled
- CORS properly configured
- Content-type protection

## 🧪 Testing

After deployment, verify:
1. **Main Site**: https://moodle.simondatalab.de/
2. **Epic Demo**: https://moodle.simondatalab.de/epic-neural-cosmos-demo.html
3. **Moodle Course**: https://moodle.simondatalab.de/course/view.php?id=2

## 🎉 Success Metrics

✅ Portfolio loads without console errors  
✅ Epic visualization initializes and auto-transitions  
✅ Mobile responsive design works correctly  
✅ THREE.js libraries load without deprecation warnings  
✅ Navigation and interactions function properly  

## 📞 Support

If you encounter issues:
1. Check Apache error logs: `/var/log/apache2/error.log`
2. Verify file permissions are correct
3. Ensure Apache modules are enabled: `mod_rewrite`, `mod_headers`, `mod_expires`
4. Test THREE.js compatibility in browser console

---

**Package Created**: 2025-10-15T00:13:58+07:00  
**Version**: Epic Neural Cosmos 2.0  
**Source**: /home/simon/Learning-Management-System-Academy/portfolio-deployment-enhanced  
